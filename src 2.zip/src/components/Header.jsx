"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Heart, Phone, Mail, Instagram, Facebook, Menu, X } from "lucide-react";

const NAV_ITEMS = [
  { href: "/", label: "Home" },
  { href: "/offers", label: "Special Offers" },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  // Body scroll lock (mobile menu offen)
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const isActive = (href) =>
    href === "/" ? pathname === "/" : pathname?.startsWith(href);

  return (
    <>
      {/* ✅ FIXED = immer sichtbar, unabhängig von parent overflow/transform */}
      <header className="fixed inset-x-0 top-3 z-[999]">
        {/* Outer wrapper: full width zum Zentrieren */}
        <div className="mx-auto max-w-6xl px-3 sm:px-4">
          {/* Visible bar: NICHT full width, rounded */}
          <div
            className={[
              "relative overflow-hidden rounded-2xl border backdrop-blur-xl",
              "supports-[backdrop-filter]:bg-slate-950/45",
              "transition-all duration-300 ease-out",
              scrolled
                ? "border-white/10 bg-slate-950/80 shadow-[0_14px_40px_rgba(0,0,0,0.50)]"
                : "border-white/10 bg-slate-950/65 shadow-[0_10px_26px_rgba(0,0,0,0.35)]",
            ].join(" ")}
          >
            {/* Brand highlight line */}
            <div className="h-[2px] w-full bg-gradient-to-r from-transparent via-sky-400/80 to-transparent" />

            {/* Top row */}
            <div className="flex items-center justify-between gap-3 px-4 py-3">
              {/* Brand */}
              <Link
                href="/"
                className="group inline-flex items-center gap-3"
                aria-label="Urlaub-GOSCH Startseite"
                onClick={() => setOpen(false)}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/urlaub-gosch-logo.png"
                  alt="Urlaub-GOSCH Logo"
                  className="h-9 w-auto drop-shadow-sm transition-transform duration-300 ease-out group-hover:scale-[1.02]"
                />
                <div className="flex flex-col leading-tight">
                  <span className="text-sm font-semibold tracking-tight text-white">
                    Urlaub-GOSCH
                  </span>
                  <span className="text-[11px] tracking-[0.18em] uppercase text-sky-200/70">
                    Nord- &amp; Ostsee
                  </span>
                </div>
              </Link>

              {/* Actions */}
              <div className="flex items-center gap-2 sm:gap-3">
                {/* Mini Contact (Desktop) */}
                <div className="hidden items-center gap-2 lg:flex">
                  <a
                    href="tel:+4943123456"
                    className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-white/90
                    transition-all duration-200 ease-out hover:bg-white/10 hover:-translate-y-[1px] hover:scale-[1.02] active:scale-[0.99]"
                  >
                    <Phone className="h-4 w-4 text-sky-300" />
                    <span>Tel.</span>
                  </a>

                  <a
                    href="mailto:info@urlaub-gosch.de"
                    className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-white/90
                    transition-all duration-200 ease-out hover:bg-white/10 hover:-translate-y-[1px] hover:scale-[1.02] active:scale-[0.99]"
                  >
                    <Mail className="h-4 w-4 text-sky-300" />
                    <span>Mail</span>
                  </a>
                </div>

                {/* Social */}
                <a
                  className="hidden sm:inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/90
                  transition-all duration-200 ease-out hover:bg-white/10 hover:-translate-y-[1px] hover:scale-[1.02] active:scale-[0.99]
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
                  href="https://facebook.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Facebook"
                  title="Facebook"
                >
                  <Facebook className="h-5 w-5 text-sky-300" />
                </a>

                <a
                  className="hidden sm:inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/90
                  transition-all duration-200 ease-out hover:bg-white/10 hover:-translate-y-[1px] hover:scale-[1.02] active:scale-[0.99]
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Instagram"
                  title="Instagram"
                >
                  <Instagram className="h-5 w-5 text-sky-300" />
                </a>

                {/* Favorites */}
                <Link
                  href="/favorites"
                  title="Favoriten"
                  className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/90
                  transition-all duration-200 ease-out hover:bg-white/10 hover:-translate-y-[1px] hover:scale-[1.02] active:scale-[0.99]
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
                  onClick={() => setOpen(false)}
                >
                  <Heart className="h-5 w-5" />
                  <span className="sr-only">Favoriten</span>
                </Link>

                {/* Mobile Menu */}
                <button
                  type="button"
                  className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/90
                  transition-all duration-200 ease-out hover:bg-white/10 hover:-translate-y-[1px] hover:scale-[1.02] active:scale-[0.99]
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 md:hidden"
                  aria-label={open ? "Menü schließen" : "Menü öffnen"}
                  onClick={() => setOpen((v) => !v)}
                >
                  {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Desktop Subnav */}
            <div className="hidden border-t border-white/10 md:block">
              <div className="flex items-center justify-between px-4 py-2">
                <div className="flex items-center gap-2">
                  {NAV_ITEMS.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={[
                        "rounded-full px-3 py-1 text-[11px] font-semibold tracking-[0.18em] uppercase transition-all duration-200 ease-out",
                        isActive(item.href)
                          ? "bg-white/10 text-white"
                          : "text-white/75 hover:text-white hover:bg-white/5",
                      ].join(" ")}
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>

                <div className="flex items-center gap-2 lg:hidden">
                  <a
                    href="tel:+4943123456"
                    className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/90
                    transition-all duration-200 ease-out hover:bg-white/10"
                    aria-label="Telefon"
                    title="Telefon"
                  >
                    <Phone className="h-4 w-4 text-sky-300" />
                  </a>
                  <a
                    href="mailto:info@urlaub-gosch.de"
                    className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/90
                    transition-all duration-200 ease-out hover:bg-white/10"
                    aria-label="E-Mail"
                    title="E-Mail"
                  >
                    <Mail className="h-4 w-4 text-sky-300" />
                  </a>
                </div>
              </div>
            </div>

            {/* Mobile Drawer: overlay, drückt NICHT hero */}
            {open && (
              <div className="absolute left-0 right-0 top-full z-[1000] md:hidden">
                <div className="mt-2 px-3 sm:px-4">
                  <div className="overflow-hidden rounded-2xl border border-white/10 bg-slate-950/90 backdrop-blur-xl shadow-[0_16px_40px_rgba(0,0,0,0.55)]">
                    <div className="px-4 pb-4 pt-3">
                      <nav className="grid gap-2">
                        {NAV_ITEMS.map((item) => (
                          <Link
                            key={item.href}
                            href={item.href}
                            onClick={() => setOpen(false)}
                            className={[
                              "rounded-xl border px-4 py-3 text-sm font-semibold transition-all duration-200 ease-out",
                              isActive(item.href)
                                ? "border-white/15 bg-white/10 text-white"
                                : "border-white/10 bg-white/5 text-white/90 hover:bg-white/10",
                            ].join(" ")}
                          >
                            {item.label}
                          </Link>
                        ))}
                      </nav>

                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <a
                          href="tel:+4943123456"
                          className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white/90
                          transition-all duration-200 ease-out hover:bg-white/10"
                        >
                          <Phone className="h-4 w-4 text-sky-300" />
                          <span>Telefon</span>
                        </a>
                        <a
                          href="mailto:info@urlaub-gosch.de"
                          className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white/90
                          transition-all duration-200 ease-out hover:bg-white/10"
                        >
                          <Mail className="h-4 w-4 text-sky-300" />
                          <span>E-Mail</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Backdrop muss FIXED sein (hinter drawer) */}
      {open && (
        <button
          aria-label="Menü schließen"
          onClick={() => setOpen(false)}
          className="fixed inset-0 z-[998] bg-black/40 backdrop-blur-[2px] md:hidden"
        />
      )}
    </>
  );
}

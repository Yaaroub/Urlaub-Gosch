export default function LastMinuteBadge({ discount }) {
  if (!discount && discount !== 0) return null;

  return (
    <div className="absolute left-2 top-2 z-10">
      <span
        className="
          relative inline-flex items-center rounded-lg
          bg-gradient-to-r from-rose-500 via-pink-500 to-rose-500
          bg-[length:200%_200%]
          px-2 py-1
          text-[12px] font-extrabold text-white
          shadow-lg
          animate-[gradient_3.5s_ease-in-out_infinite]
        "
      >
        −{discount}% Last-Minute
        <span
          className="absolute inset-0 -z-10 rounded-lg blur-md opacity-60
                     bg-gradient-to-r from-rose-400 via-pink-400 to-rose-400
                     animate-pulse"
        />
      </span>
    </div>
  );
}

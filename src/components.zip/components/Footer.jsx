import {
  ArrowRight,
  Facebook,
  Headphones,
  Home,
  Instagram,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  UserRound,
  Waves,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";

const HERO_IMAGE = "/hero/hero.jpeg";

const trustItems = [
  {
    icon: Home,
    title: "Handverlesen",
    text: "Ausgewählte Ferienhäuser und Apartments an Nord- und Ostsee.",
  },
  {
    icon: UserRound,
    title: "Persönlich",
    text: "Service vor, während und nach deinem Urlaub.",
  },
  {
    icon: ShieldCheck,
    title: "Sicher & fair",
    text: "Klare Informationen, transparente Abläufe und direkte Anfrage.",
  },
];

const footerGroups = [
  {
    icon: Home,
    title: "Unterkünfte",
    links: [
      ["Ferienhäuser", "/offers"],
      ["Apartments", "/offers"],
      ["Last-Minute-Angebote", "/offers"],
      ["Merkliste", "/favorites"],
    ],
  },
  {
    icon: Waves,
    title: "Regionen",
    links: [
      ["Nordsee", "/#regionen"],
      ["Ostsee", "/#regionen"],
      ["Inspirationen", "/blog"],
      ["Regionen entdecken", "/#regionen"],
    ],
  },
  {
    icon: Headphones,
    title: "Service",
    links: [
      ["Kontakt & Support", "/contact"],
      ["Für Eigentümer", "/contact"],
      ["Häufige Fragen", "/contact"],
      ["Über uns", "/contact"],
    ],
  },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-[#050e1a] text-white">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#e8c375]/70 to-transparent" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-80 w-[900px] -translate-x-1/2 rounded-full bg-sky-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 py-10 sm:px-6 md:py-14 lg:px-8">
        {/* Trust Bar */}
        <div className="grid overflow-hidden rounded-[1.6rem] border border-white/10 bg-white/[0.035] shadow-[0_24px_80px_rgba(0,0,0,0.35)] backdrop-blur-xl md:grid-cols-3">
          {trustItems.map((item, index) => {
            const Icon = item.icon;

            return (
              <div
                key={item.title}
                className={[
                  "flex gap-4 p-5 sm:p-6",
                  index !== 0
                    ? "border-t border-white/10 md:border-l md:border-t-0"
                    : "",
                ].join(" ")}
              >
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/[0.04] text-[#e8c375] ring-1 ring-white/10">
                  <Icon className="h-6 w-6 stroke-[1.8]" />
                </div>

                <div>
                  <h3 className="font-serif text-lg font-semibold text-white">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-6 text-white/65">
                    {item.text}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Main Footer */}
        <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_1.65fr] lg:gap-14">
          {/* Brand */}
          <div>
            <Link href="/" aria-label="Zur Startseite" className="inline-flex">
              <Image
                src="/urlaub-gosch-logo.png"
                alt="Urlaub-GOSCH Logo"
                width={170}
                height={90}
                sizes="170px"
                quality={82}
                className="h-16 w-auto object-contain sm:h-20"
              />
            </Link>

            <p className="mt-6 font-serif text-lg font-semibold text-[#e8c375]">
              Persönlich. Regional. Vertrauensvoll.
            </p>

            <p className="mt-4 max-w-md text-sm leading-7 text-white/66 sm:text-base sm:leading-8">
              Urlaub-GOSCH vermittelt handverlesene Ferienunterkünfte an Nord-
              und Ostsee – mit persönlichem Service, klarer Suche und echter
              Liebe zur Küste.
            </p>

            <div className="mt-6 space-y-3 text-sm text-white/68">
              <a
                href="tel:+4943123456"
                className="flex w-fit items-center gap-3 transition hover:text-white"
              >
                <Phone className="h-4 w-4 text-[#e8c375]" />
                +49 431 23456
              </a>

              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-[#e8c375]" />
                Schleswig-Holstein &amp; Küste
              </div>
            </div>

            <div className="mt-7 flex items-center gap-3">
              <SocialLink
                href="https://facebook.com"
                label="Facebook"
                icon={Facebook}
              />
              <SocialLink
                href="https://instagram.com"
                label="Instagram"
                icon={Instagram}
              />
              <SocialLink
                href="mailto:info@urlaub-gosch.de"
                label="E-Mail"
                icon={Mail}
              />
            </div>
          </div>

          {/* Link Cards */}
          <div className="grid gap-4 sm:grid-cols-3">
            {footerGroups.map((group) => (
              <FooterCard key={group.title} {...group} />
            ))}
          </div>
        </div>

        {/* Owner CTA */}
        <div className="mt-10 overflow-hidden rounded-[1.7rem] border border-white/10 bg-white/[0.035] shadow-[0_20px_70px_rgba(0,0,0,0.22)]">
          <div className="grid md:grid-cols-[300px_1fr] lg:grid-cols-[360px_1fr]">
            <div className="relative min-h-52 md:min-h-full">
              <Image
                src={HERO_IMAGE}
                alt="Ferienimmobilie an der Küste"
                fill
                quality={68}
                sizes="(max-width: 768px) 100vw, 360px"
                className="object-cover object-center"
              />
              <div className="absolute inset-0 bg-[#050e1a]/25" />
            </div>

            <div className="p-6 sm:p-8 lg:p-10">
              <p className="text-xs font-bold uppercase tracking-[0.22em] text-[#e8c375]">
                Für Eigentümer
              </p>

              <h2 className="mt-3 max-w-2xl font-serif text-2xl leading-tight text-white sm:text-3xl lg:text-4xl">
                Sie besitzen eine{" "}
                <span className="italic text-[#e8c375]">
                  Ferienimmobilie?
                </span>
              </h2>

              <p className="mt-4 max-w-2xl text-sm leading-7 text-white/66 sm:text-base sm:leading-8">
                Werden Sie Vermieter bei Urlaub-GOSCH und profitieren Sie von
                persönlicher Betreuung, strukturierter Präsentation und einer
                starken Vermarktung Ihrer Unterkunft.
              </p>

              <Link
                href="/contact"
                className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-3 rounded-2xl bg-[#e8c375] px-6 py-3.5 text-sm font-extrabold uppercase tracking-[0.12em] text-[#07131f] transition hover:-translate-y-0.5 hover:bg-white sm:w-auto"
              >
                Ferienimmobilie vermieten
                <ArrowRight className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-9 flex flex-col gap-5 border-t border-white/10 pt-7 text-sm text-white/48 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} Urlaub-GOSCH. Alle Rechte vorbehalten.</p>

          <div className="flex flex-wrap gap-x-7 gap-y-3">
            <Link href="/impressum" className="transition hover:text-white">
              Impressum
            </Link>
            <Link href="/datenschutz" className="transition hover:text-white">
              Datenschutz
            </Link>
            <Link href="/agb" className="transition hover:text-white">
              AGB
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCard({ icon: Icon, title, links }) {
  return (
    <div className="rounded-[1.45rem] border border-white/10 bg-white/[0.035] p-5 transition hover:bg-white/[0.055] sm:p-6">
      <Icon className="h-8 w-8 text-[#e8c375]" />

      <h3 className="mt-5 text-xs font-extrabold uppercase tracking-[0.18em] text-white">
        {title}
      </h3>

      <ul className="mt-6 space-y-4 text-sm text-white/62">
        {links.map(([label, href]) => (
          <li key={label}>
            <Link href={href} className="transition hover:text-white">
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SocialLink({ href, label, icon: Icon }) {
  const external = href.startsWith("http");

  return (
    <a
      href={href}
      target={external ? "_blank" : undefined}
      rel={external ? "noopener noreferrer" : undefined}
      aria-label={label}
      title={label}
      className="grid h-11 w-11 place-items-center rounded-full border border-white/10 bg-white/[0.035] text-white/72 transition hover:-translate-y-0.5 hover:bg-white/10 hover:text-white"
    >
      <Icon className="h-5 w-5" />
    </a>
  );
}
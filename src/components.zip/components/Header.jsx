"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Heart, Menu, Search, X } from "lucide-react";

const NAV = [
  { href: "/offers", label: "Unterkünfte" },
  { href: "/#regionen", label: "Regionen" },
  { href: "/blog", label: "Inspiration" },
  { href: "/contact", label: "Service" },
];

export default function Header() {
  const pathname = usePathname();

  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const isHome = pathname === "/";

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(!isHome || window.scrollY > 32);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => window.removeEventListener("scroll", handleScroll);
  }, [isHome]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  const compact = scrolled || open;

  const isActive = (href) => {
    if (href.startsWith("/#")) return false;
    return href === "/" ? pathname === "/" : pathname?.startsWith(href);
  };

  return (
    <>
      <header
        className="
          fixed inset-x-0 top-0 z-50
          px-4 pt-4 transition-all duration-300
          sm:px-6 sm:pt-5
          lg:px-8
        "
      >
        <div
          className={[
            `
              mx-auto flex items-center justify-between transition-all duration-300
              max-w-7xl
            `,
            compact
              ? `
                h-[62px] rounded-full bg-white/88 px-4
                shadow-[0_18px_60px_rgba(7,19,31,0.13)]
                backdrop-blur-2xl
                sm:h-[68px] sm:px-5
              `
              : `
                h-[76px] px-0
                bg-transparent shadow-none backdrop-blur-0
                sm:h-[82px]
              `,
          ].join(" ")}
        >
          <Link
            href="/"
            aria-label="Zur Startseite"
            className="flex shrink-0 items-center"
          >
            <Image
              src="/urlaub-gosch-logo.png"
              alt="Urlaub Gosch Logo"
              width={160}
              height={90}
              sizes="(max-width: 640px) 112px, 160px"
              priority
              quality={85}
              className={[
                "w-auto object-contain transition-all duration-300",
                compact ? "h-10 sm:h-12" : "h-12 sm:h-14 lg:h-16",
              ].join(" ")}
            />
          </Link>

          <nav className="hidden items-center gap-2 lg:flex">
            {NAV.map((item) => {
              const active = isActive(item.href);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={[
                    `
                      rounded-full px-4 py-2.5
                      text-sm font-extrabold tracking-wide
                      transition
                    `,
                    active
                      ? "bg-[#07131f] text-white"
                      : "text-[#07131f]/80 hover:bg-white/45 hover:text-[#07131f]",
                  ].join(" ")}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex shrink-0 items-center gap-2 sm:gap-3">
            <Link
              href="/favorites"
              aria-label="Favoriten"
              className={[
                `
                  grid place-items-center rounded-full
                  text-[#07131f] transition
                  hover:bg-white/70
                `,
                compact
                  ? "h-10 w-10 bg-white/55 sm:h-11 sm:w-11"
                  : "h-11 w-11 bg-white/28 backdrop-blur-md sm:h-12 sm:w-12",
              ].join(" ")}
            >
              <Heart className="h-5 w-5" />
            </Link>

            <Link
              href="/offers"
              className={[
                `
                  hidden items-center gap-2 rounded-full
                  bg-[#e8c375] text-sm font-extrabold text-[#07131f]
                  shadow-[0_12px_35px_rgba(7,19,31,0.12)]
                  transition hover:-translate-y-0.5 hover:bg-[#f2d58e]
                  md:inline-flex
                `,
                compact
                  ? "min-h-11 px-5 py-3"
                  : "min-h-12 px-6 py-3.5",
              ].join(" ")}
            >
              <Search className="h-4 w-4" />
              Suchen
            </Link>

            <button
              type="button"
              onClick={() => setOpen((value) => !value)}
              aria-label={open ? "Menü schließen" : "Menü öffnen"}
              aria-expanded={open}
              className={[
                `
                  grid place-items-center rounded-full
                  text-[#07131f] transition hover:bg-white/70
                  lg:hidden
                `,
                compact
                  ? "h-10 w-10 bg-white/55 sm:h-11 sm:w-11"
                  : "h-11 w-11 bg-white/28 backdrop-blur-md sm:h-12 sm:w-12",
              ].join(" ")}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {open && (
        <div className="fixed inset-0 z-40 bg-[#07131f]/96 px-4 pb-6 pt-24 text-white backdrop-blur-2xl lg:hidden">
          <div className="mx-auto flex h-full max-w-md flex-col">
            <div className="rounded-[2rem] border border-white/10 bg-white/[0.08] p-2 shadow-2xl shadow-black/30">
              {NAV.map((item) => {
                const active = isActive(item.href);

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={[
                      `
                        flex items-center justify-between rounded-[1.35rem]
                        px-5 py-4 text-lg font-semibold transition
                      `,
                      active
                        ? "bg-[#e8c375] text-[#07131f]"
                        : "text-white/82 hover:bg-white/10 hover:text-white",
                    ].join(" ")}
                  >
                    {item.label}
                    <span className="text-sm opacity-60">→</span>
                  </Link>
                );
              })}

              <Link
                href="/favorites"
                onClick={() => setOpen(false)}
                className="
                  mt-2 flex items-center justify-between rounded-[1.35rem]
                  px-5 py-4 text-lg font-semibold text-white/82
                  transition hover:bg-white/10 hover:text-white
                "
              >
                Favoriten
                <Heart className="h-5 w-5" />
              </Link>
            </div>

            <div className="mt-auto rounded-[2rem] border border-white/10 bg-white/[0.08] p-5 shadow-2xl shadow-black/20">
              <p className="text-sm leading-6 text-white/70">
                Finde deine passende Ferienunterkunft an Nord- und Ostsee.
              </p>

              <Link
                href="/offers"
                onClick={() => setOpen(false)}
                className="
                  mt-4 inline-flex min-h-12 w-full items-center justify-center gap-2
                  rounded-full bg-[#e8c375] px-5 py-3.5
                  text-sm font-bold text-[#07131f]
                  transition hover:bg-white
                "
              >
                Unterkunft suchen
                <Search className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Home, ShieldCheck, UserRound } from "lucide-react";

const HERO_IMAGE = "/hero/hero.jpeg";

const trustItems = [
  {
    icon: Home,
    title: "Ausgewählte Unterkünfte",
    text: "Sorgfältig kuratiert an Nord- und Ostsee.",
  },
  {
    icon: UserRound,
    title: "Persönlicher Service",
    text: "Vor, während und nach deinem Urlaub.",
  },
  {
    icon: ShieldCheck,
    title: "Sicher & fair",
    text: "Transparente Abläufe und direkte Buchung.",
  },
];

export default function HomeHero({ hasActiveFilters, resultsCount }) {
  return (
    <section
      className="
        relative isolate overflow-hidden bg-[#07131f] text-[#07131f]
        min-h-[680px]
        md:h-[100svh] md:min-h-[680px] md:max-h-[920px]
      "
    >
      <div className="absolute inset-0 -z-10">
        <Image
          src={HERO_IMAGE}
          alt="Ferienhaus am Meer"
          fill
          priority
          fetchPriority="high"
          quality={78}
          sizes="100vw"
          className="
            object-cover
            object-[64%_center]
            md:object-[62%_center]
            xl:object-center
          "
        />

        <div className="absolute inset-0 bg-gradient-to-b from-white/96 via-white/74 to-[#07131f]/92 md:hidden" />

        <div className="absolute inset-0 hidden bg-gradient-to-r from-white/96 via-white/72 to-white/5 md:block" />
        <div className="absolute inset-0 hidden bg-gradient-to-t from-[#07131f]/82 via-transparent to-transparent md:block" />
      </div>

      <div
        className="
          mx-auto grid h-full w-full max-w-7xl grid-rows-[1fr_auto]
          px-4 pb-5 pt-24
          sm:px-6 sm:pt-28
          md:px-8 md:pb-6 md:pt-28
          lg:px-10 lg:pt-30
          [@media(max-height:780px)]:pt-22
          [@media(max-height:780px)]:pb-4
        "
      >
        <div className="flex items-center">
          <div className="w-full max-w-[620px] lg:max-w-[680px]">
            <p
              className="
                text-[10px] font-bold uppercase tracking-[0.28em]
                text-[#ad8d47]
                sm:text-xs sm:tracking-[0.36em]
              "
            >
              Nordsee · Ostsee · Ferienunterkünfte
            </p>

            <h1
              className="
                mt-4 font-serif font-semibold leading-[0.9]
                tracking-[-0.055em] text-[#071b31]
                text-[clamp(3rem,11vw,5rem)]
                sm:text-[clamp(3.6rem,8vw,5.7rem)]
                lg:text-[clamp(4rem,5.7vw,6rem)]
                [@media(max-height:780px)]:mt-3
                [@media(max-height:780px)]:text-[clamp(3.5rem,5vw,5.2rem)]
              "
            >
              Deine Auszeit
              <span className="block italic font-normal text-[#d2ad69]">
                am Meer.
              </span>
            </h1>

            <p
              className="
                mt-5 max-w-xl text-[15px] leading-7 text-[#102033]/82
                sm:text-base sm:leading-8
                md:max-w-2xl md:text-[17px]
                [@media(max-height:780px)]:mt-4
                [@media(max-height:780px)]:max-w-[600px]
                [@media(max-height:780px)]:text-[15px]
                [@media(max-height:780px)]:leading-7
              "
            >
              Entdecke handverlesene Ferienhäuser und Apartments an Nord- und
              Ostsee – persönlich ausgewählt, übersichtlich geplant und perfekt
              für Familie, Hund oder ruhige Tage am Wasser.
            </p>

            <div
              className="
                mt-7 flex flex-col gap-3 sm:flex-row sm:items-center
                [@media(max-height:780px)]:mt-5
              "
            >
              <a
                href="#suche"
                className="
                  group inline-flex min-h-12 items-center justify-center gap-3
                  rounded-2xl bg-[#e8c375] px-6 py-3.5
                  text-sm font-extrabold text-[#07131f]
                  shadow-[0_20px_60px_rgba(7,19,31,0.18)]
                  transition hover:-translate-y-0.5 hover:bg-[#f2d58e]
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#07131f]/45
                  sm:px-7
                "
              >
                Unterkunft finden
                <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
              </a>

              <Link
                href="/offers"
                className="
                  inline-flex min-h-12 items-center justify-center
                  rounded-2xl border border-[#07131f]/18 bg-white/35
                  px-6 py-3.5 text-sm font-extrabold text-[#07131f]
                  backdrop-blur-xl transition hover:-translate-y-0.5 hover:bg-white/60
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#07131f]/35
                  sm:px-7
                "
              >
                Angebote ansehen
              </Link>

              {hasActiveFilters && (
                <span className="text-center text-sm font-semibold text-[#07131f]/75 sm:text-left">
                  {resultsCount} Treffer
                </span>
              )}
            </div>
          </div>
        </div>

        <div
          className="
            grid overflow-hidden rounded-[1.35rem]
            border border-white/10 bg-[#061421]/90
            shadow-[0_26px_80px_rgba(0,0,0,0.32)]
            backdrop-blur-2xl
            sm:grid-cols-3
            lg:max-w-[980px]
          "
        >
          {trustItems.map((item, index) => {
            const Icon = item.icon;

            return (
              <div
                key={item.title}
                className={[
                  `
                    flex gap-4 p-4 text-white
                    sm:flex-col sm:p-5
                    lg:flex-row lg:p-5
                    xl:p-6
                    [@media(max-height:780px)]:p-4
                  `,
                  index !== 0
                    ? "border-t border-white/10 sm:border-l sm:border-t-0"
                    : "",
                ].join(" ")}
              >
                <div
                  className="
                    grid h-10 w-10 shrink-0 place-items-center
                    rounded-2xl text-[#0b6fc9]
                    lg:h-11 lg:w-11
                  "
                >
                  <Icon className="h-7 w-7 stroke-[1.7] lg:h-8 lg:w-8" />
                </div>

                <div>
                  <h3
                    className="
                      text-sm font-bold leading-snug text-white
                      lg:text-[15px]
                    "
                  >
                    {item.title}
                  </h3>

                  <p
                    className="
                      mt-1.5 text-xs leading-5 text-white/70
                      lg:text-sm lg:leading-6
                      [@media(max-height:780px)]:text-xs
                      [@media(max-height:780px)]:leading-5
                    "
                  >
                    {item.text}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
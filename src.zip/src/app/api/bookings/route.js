import prisma from "@/lib/db";

/** Utils */
function dateOnly(input) {
  const d = typeof input === "string" ? new Date(input) : new Date(input);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function addDays(d, n) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}
function fmtISODate(d) {
  return d.toISOString().slice(0, 10);
}

/**
 * GET /api/bookings?propertyId=1
 * -> Liste aller Buchungen (ISO-Strings)
 */
export async function GET(req) {
  try {
    const sp = new URL(req.url).searchParams;
    const pid = Number(sp.get("propertyId"));
    if (!pid) return Response.json([]);

    const rows = await prisma.booking.findMany({
      where: { propertyId: pid },
      orderBy: { startDate: "asc" },
      select: { id: true, startDate: true, endDate: true, guestName: true },
    });

    // Next serialisiert Date automatisch zu ISO-String
    return Response.json(rows);
  } catch (e) {
    console.error("GET /api/bookings error:", e);
    return Response.json([], { status: 200 });
  }
}

/**
 * POST /api/bookings
 * Body: { propertyId, arrival: "YYYY-MM-DD", departure: "YYYY-MM-DD", guestName? }
 * -> legt Buchung an (wenn frei) und gibt Preisdetails zurück
 * WIRD VOM ADMIN-BEREICH GENUTZT (Blockieren/Buchen)
 */
export async function POST(req) {
  try {
    const { propertyId, arrival, departure, guestName } = await req.json();

    const pid = Number(propertyId);
    if (!pid || !arrival || !departure) {
      return Response.json(
        { error: "propertyId, arrival und departure sind erforderlich." },
        { status: 400 }
      );
    }

    const start = dateOnly(arrival);
    const end = dateOnly(departure);
    if (!(end > start)) {
      return Response.json(
        { error: "departure muss nach arrival liegen." },
        { status: 400 }
      );
    }

    const property = await prisma.property.findUnique({
      where: { id: pid },
      select: { id: true, title: true },
    });
    if (!property) {
      return Response.json(
        { error: "Property nicht gefunden." },
        { status: 404 }
      );
    }

    // Verfügbarkeit prüfen: Overlap wenn NICHT (bestehendesEnde <= start ODER bestehenderStart >= end)
    const overlap = await prisma.booking.findFirst({
      where: {
        propertyId: pid,
        NOT: [
          { endDate: { lte: start } }, // komplett davor
          { startDate: { gte: end } }, // komplett danach
        ],
      },
      select: { id: true, startDate: true, endDate: true },
    });

    if (overlap) {
      return Response.json(
        {
          error: "Zeitraum ist bereits belegt.",
          conflict: {
            id: overlap.id,
            startDate: overlap.startDate,
            endDate: overlap.endDate,
          },
        },
        { status: 409 }
      );
    }

    // Preis berechnen (wie in /api/price)
    const nights = Math.round((end - start) / 86400000);
    const days = Array.from({ length: nights }, (_, i) => addDays(start, i));

    const pricePeriods = await prisma.pricePeriod.findMany({
      where: { propertyId: pid },
      orderBy: { startDate: "asc" },
      select: { startDate: true, endDate: true, pricePerNight: true },
    });
    if (pricePeriods.length === 0) {
      return Response.json(
        { error: "Keine Preiszeiten hinterlegt." },
        { status: 409 }
      );
    }

    let base = 0;
    const breakdown = [];
    for (const night of days) {
      const matched = pricePeriods.find(
        (pp) =>
          night >= dateOnly(pp.startDate) && night < dateOnly(pp.endDate)
      );
      if (!matched) {
        return Response.json(
          {
            error:
              "Für den gewählten Zeitraum existiert keine durchgehende Preiszeit.",
            missingDate: fmtISODate(night),
          },
          { status: 409 }
        );
      }
      const price = Number(matched.pricePerNight);
      base += price;
      breakdown.push({ date: fmtISODate(night), price });
    }

    const extraRows = await prisma.extraCost.findMany({
      where: { propertyId: pid },
      select: { id: true, title: true, amount: true, isDaily: true },
    });

    let extras = 0;
    for (const e of extraRows) {
      if (e.isDaily) extras += (e.amount / 100) * nights;
      else extras += e.amount / 100;
    }

    const total = base + extras;

    // Buchung anlegen (harte Blockierung)
    const booking = await prisma.booking.create({
      data: {
        propertyId: pid,
        startDate: start,
        endDate: end,
        guestName: guestName?.trim() || null,
      },
      select: { id: true, startDate: true, endDate: true, guestName: true },
    });

    const fees = extraRows.map((e) => ({
      id: e.id,
      name: e.title,
      kind: e.isDaily ? "PER_NIGHT" : "FIXED",
      amount: e.amount, // Cent
    }));

    return Response.json({
      ok: true,
      booking,
      price: { nights, base, extras, total, breakdown, fees },
    });
  } catch (e) {
    console.error("POST /api/bookings error:", e);
    return Response.json(
      { error: "Interner Fehler beim Anlegen der Buchung." },
      { status: 500 }
    );
  }
}

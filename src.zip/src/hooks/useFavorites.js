// src/hooks/useFavorites.js
"use client";
export { useFavoritesCtx as default } from "@/context/FavoritesProvider";
